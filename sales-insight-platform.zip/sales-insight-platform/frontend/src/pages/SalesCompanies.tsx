import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { SearchBar, ActiveFilters } from '@/components/SearchBar'
import { useSearchStore } from '@/stores/searchStore'
import { formatRelativeDate } from '@/lib/utils'
import { Filter, Download } from 'lucide-react'

export default function SalesCompanies() {
  const { results, totalHits, isLoading, filters, setFilters } = useSearchStore()
  const [selectedPeriod, setSelectedPeriod] = useState<'1M' | '3M' | 'YTD'>('1M')
  const [showFilters, setShowFilters] = useState(true)

  const companyTypes = ['銀行', '証券', '保険', 'その他']
  const regions = ['全国', '関東', '関西', '中部', '九州', '東北', '北海道', '中国', '四国']
  const sources = ['ニッキン', 'R&I', 'その他']
  const importanceLevels = [
    { value: 'high', label: '重要' },
    { value: 'medium', label: '中' },
    { value: 'low', label: '低' },
  ]

  const toggleFilter = (filterType: 'salesCompanyType' | 'salesCompanyRegion' | 'source' | 'importance', value: string) => {
    const currentValues = filters[filterType] as string[]
    const newValues = currentValues.includes(value)
      ? currentValues.filter(v => v !== value)
      : [...currentValues, value]
    setFilters({ [filterType]: newValues })
  }

  return (
    <div className="p-6 space-y-6">
      {/* ヘッダー */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">販売会社分析</h1>
          <p className="text-muted-foreground mt-1">
            販売会社の動向を多角的に分析
          </p>
        </div>
        <Button className="gap-2">
          <Download className="h-4 w-4" />
          レポート出力
        </Button>
      </div>

      {/* 検索バー */}
      <div className="space-y-3">
        <SearchBar />
        <ActiveFilters />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* 左サイドバー - フィルタ */}
        <div className={`lg:col-span-1 space-y-4 ${!showFilters && 'hidden lg:block'}`}>
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">絞り込み</CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setFilters({
                    salesCompanyType: [],
                    salesCompanyRegion: [],
                    source: [],
                    importance: [],
                  })}
                >
                  リセット
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* 業態 */}
              <div>
                <h4 className="text-sm font-medium mb-2">業態</h4>
                <div className="space-y-2">
                  {companyTypes.map(type => (
                    <label key={type} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={filters.salesCompanyType.includes(type)}
                        onChange={() => toggleFilter('salesCompanyType', type)}
                        className="rounded border-gray-300"
                      />
                      <span className="text-sm">{type}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* 地域 */}
              <div>
                <h4 className="text-sm font-medium mb-2">地域</h4>
                <div className="space-y-2 max-h-40 overflow-y-auto custom-scrollbar">
                  {regions.map(region => (
                    <label key={region} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={filters.salesCompanyRegion.includes(region)}
                        onChange={() => toggleFilter('salesCompanyRegion', region)}
                        className="rounded border-gray-300"
                      />
                      <span className="text-sm">{region}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* 情報源 */}
              <div>
                <h4 className="text-sm font-medium mb-2">情報源</h4>
                <div className="space-y-2">
                  {sources.map(source => (
                    <label key={source} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={filters.source.includes(source)}
                        onChange={() => toggleFilter('source', source)}
                        className="rounded border-gray-300"
                      />
                      <span className="text-sm">{source}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* 重要度 */}
              <div>
                <h4 className="text-sm font-medium mb-2">重要度</h4>
                <div className="space-y-2">
                  {importanceLevels.map(({ value, label }) => (
                    <label key={value} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={filters.importance.includes(value)}
                        onChange={() => toggleFilter('importance', value)}
                        className="rounded border-gray-300"
                      />
                      <span className="text-sm">{label}</span>
                    </label>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* メインコンテンツ */}
        <div className="lg:col-span-3 space-y-4">
          {/* 期間タブ */}
          <Tabs value={selectedPeriod} onValueChange={(v) => setSelectedPeriod(v as any)}>
            <TabsList>
              <TabsTrigger value="1M">1ヶ月</TabsTrigger>
              <TabsTrigger value="3M">3ヶ月</TabsTrigger>
              <TabsTrigger value="YTD">年初来</TabsTrigger>
            </TabsList>
          </Tabs>

          {/* 結果表示 */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">
                  検索結果 <span className="text-muted-foreground font-normal">({totalHits}件)</span>
                </CardTitle>
                <Button variant="outline" size="sm" className="lg:hidden" onClick={() => setShowFilters(!showFilters)}>
                  <Filter className="h-4 w-4 mr-2" />
                  フィルタ
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-3">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="h-24 bg-muted animate-pulse rounded" />
                  ))}
                </div>
              ) : results.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <p>該当する記事が見つかりませんでした</p>
                  <p className="text-sm mt-1">検索条件を変更してみてください</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {results.map((article, index) => (
                    <div
                      key={article.id}
                      className="p-4 rounded-lg border hover:bg-accent transition-colors cursor-pointer"
                    >
                      <div className="space-y-2">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <Badge variant={article.importance === 'high' ? 'destructive' : 'secondary'}>
                                {article.importance === 'high' ? '重要' : article.importance === 'medium' ? '中' : '低'}
                              </Badge>
                              <Badge variant="outline">{article.source}</Badge>
                              {article.salesCompanyName && (
                                <Badge>{article.salesCompanyName}</Badge>
                              )}
                            </div>
                            <h3 className="font-medium leading-snug mb-1">
                              {article.title}
                            </h3>
                            <p className="text-sm text-muted-foreground line-clamp-2">
                              {article.summary}
                            </p>
                          </div>
                          <div className="text-xs text-muted-foreground whitespace-nowrap">
                            {formatRelativeDate(article.publishedAt)}
                          </div>
                        </div>
                        {article.tags && article.tags.length > 0 && (
                          <div className="flex flex-wrap gap-1">
                            {article.tags.map(tag => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
