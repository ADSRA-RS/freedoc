import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { SearchBar } from '@/components/SearchBar'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

const fundData = [
  { category: '国内株式', count: 145, trend: 12 },
  { category: '外国株式', count: 132, trend: 8 },
  { category: 'バランス', count: 98, trend: -3 },
  { category: '国内債券', count: 76, trend: -5 },
  { category: '外国債券', count: 65, trend: 2 },
  { category: 'REIT', count: 42, trend: 15 },
]

export default function Products() {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">投信・商品分析</h1>
        <p className="text-muted-foreground mt-1">
          投資信託と商品の動向を分析
        </p>
      </div>

      <SearchBar />

      <div className="grid gap-6 md:grid-cols-2">
        {/* カテゴリ別記事数 */}
        <Card>
          <CardHeader>
            <CardTitle>投信カテゴリ別記事数</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={fundData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="category" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip />
                <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* トレンド */}
        <Card>
          <CardHeader>
            <CardTitle>注目カテゴリ</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {fundData.map(({ category, count, trend }) => (
                <div key={category} className="flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="font-medium">{category}</div>
                    <div className="text-sm text-muted-foreground">{count}件の記事</div>
                  </div>
                  <Badge variant={trend > 0 ? 'success' : trend < 0 ? 'destructive' : 'secondary'}>
                    {trend > 0 ? '+' : ''}{trend}%
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 最新の商品関連記事 */}
      <Card>
        <CardHeader>
          <CardTitle>最新の商品関連記事</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[
              { title: 'ESG投資信託の新規設定が過去最高ペース', fund: 'ESG関連', date: '2日前' },
              { title: 'グローバル株式ファンドに資金流入続く', fund: '外国株式', date: '3日前' },
              { title: 'インデックスファンドの低コスト化が加速', fund: '国内株式', date: '5日前' },
            ].map((article, i) => (
              <div key={i} className="p-3 rounded-lg border hover:bg-accent transition-colors cursor-pointer">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="outline">{article.fund}</Badge>
                    </div>
                    <h4 className="text-sm font-medium">{article.title}</h4>
                  </div>
                  <span className="text-xs text-muted-foreground whitespace-nowrap ml-4">
                    {article.date}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
