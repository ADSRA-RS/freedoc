import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { TrendingUp, TrendingDown, Minus, FileText, Building2, AlertCircle } from 'lucide-react'
import { meiliClient, INDEX_NAME, ArticleDocument } from '@/lib/meilisearch'
import { formatNumber, formatPercent, formatRelativeDate } from '@/lib/utils'
import { useDashboardStore } from '@/stores/searchStore'

interface KPICardProps {
  title: string
  value: number
  change?: number
  changeLabel?: string
  icon: React.ReactNode
  trend?: 'up' | 'down' | 'neutral'
}

function KPICard({ title, value, change, changeLabel, icon, trend }: KPICardProps) {
  const getTrendColor = () => {
    if (!trend) return 'text-neutral'
    return trend === 'up' ? 'text-[hsl(var(--increase))]' : 
           trend === 'down' ? 'text-[hsl(var(--decrease))]' : 'text-neutral'
  }
  
  const getTrendIcon = () => {
    if (!trend) return <Minus className="h-4 w-4" />
    return trend === 'up' ? <TrendingUp className="h-4 w-4" /> :
           trend === 'down' ? <TrendingDown className="h-4 w-4" /> :
           <Minus className="h-4 w-4" />
  }

  return (
    <Card className="animate-fade-in hover:shadow-md transition-shadow">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <div className="text-muted-foreground">{icon}</div>
      </CardHeader>
      <CardContent>
        <div className="text-3xl font-bold tabular-nums">{formatNumber(value)}</div>
        {change !== undefined && (
          <div className={`flex items-center gap-1 text-sm mt-2 ${getTrendColor()}`}>
            {getTrendIcon()}
            <span className="font-medium">{formatPercent(change, 1)}</span>
            {changeLabel && <span className="text-muted-foreground ml-1">{changeLabel}</span>}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

interface RecentArticle {
  id: string
  title: string
  source: string
  salesCompanyName?: string
  importance: string
  publishedAt: string
}

export default function Dashboard() {
  const [recentArticles, setRecentArticles] = useState<RecentArticle[]>([])
  const [loading, setLoading] = useState(true)
  const { kpis, setKPIs } = useDashboardStore()

  useEffect(() => {
    loadDashboardData()
  }, [])

  const loadDashboardData = async () => {
    try {
      setLoading(true)
      const index = meiliClient.index<ArticleDocument>(INDEX_NAME)
      
      // 全記事数取得
      const stats = await index.getStats()
      
      // 最近の記事取得
      const recent = await index.search('', {
        limit: 5,
        sort: ['publishedAt:desc']
      })
      
      // 今週の記事数（簡易計算）
      const oneWeekAgo = new Date()
      oneWeekAgo.setDate(oneWeekAgo.getDate() - 7)
      const thisWeek = await index.search('', {
        filter: `publishedAt > ${oneWeekAgo.getTime() / 1000}`,
        limit: 0
      })
      
      setKPIs({
        totalArticles: stats.numberOfDocuments,
        newArticlesThisWeek: thisWeek.estimatedTotalHits || 0,
      })
      
      setRecentArticles(recent.hits.map(hit => ({
        id: hit.id,
        title: hit.title,
        source: hit.source,
        salesCompanyName: hit.salesCompanyName,
        importance: hit.importance,
        publishedAt: hit.publishedAt,
      })))
      
    } catch (error) {
      console.error('Failed to load dashboard data:', error)
    } finally {
      setLoading(false)
    }
  }

  const getImportanceBadge = (importance: string) => {
    switch (importance) {
      case 'high':
        return <Badge variant="destructive">重要</Badge>
      case 'medium':
        return <Badge variant="secondary">中</Badge>
      default:
        return <Badge variant="outline">低</Badge>
    }
  }

  return (
    <div className="space-y-6 p-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">ダッシュボード</h1>
        <p className="text-muted-foreground mt-1">
          今日の販売会社動向を30秒で把握
        </p>
      </div>

      {/* KPIカード */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <KPICard
          title="総記事数"
          value={kpis.totalArticles}
          icon={<FileText className="h-4 w-4" />}
        />
        <KPICard
          title="今週の新着"
          value={kpis.newArticlesThisWeek}
          change={15.2}
          changeLabel="前週比"
          icon={<TrendingUp className="h-4 w-4" />}
          trend="up"
        />
        <KPICard
          title="注目販売会社"
          value={12}
          change={-5.1}
          changeLabel="前週比"
          icon={<Building2 className="h-4 w-4" />}
          trend="down"
        />
        <KPICard
          title="重要アラート"
          value={3}
          icon={<AlertCircle className="h-4 w-4" />}
          trend="neutral"
        />
      </div>

      {/* 最新記事 */}
      <Card className="animate-fade-in delay-200">
        <CardHeader>
          <CardTitle>最新の記事</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-16 bg-muted animate-pulse rounded" />
              ))}
            </div>
          ) : (
            <div className="space-y-3">
              {recentArticles.map((article, index) => (
                <div
                  key={article.id}
                  className="flex items-start justify-between p-3 rounded-lg border hover:bg-accent transition-colors cursor-pointer"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center gap-2">
                      {getImportanceBadge(article.importance)}
                      <Badge variant="outline">{article.source}</Badge>
                      {article.salesCompanyName && (
                        <span className="text-xs text-muted-foreground">
                          {article.salesCompanyName}
                        </span>
                      )}
                    </div>
                    <h4 className="text-sm font-medium leading-snug">
                      {article.title}
                    </h4>
                  </div>
                  <div className="text-xs text-muted-foreground whitespace-nowrap ml-4">
                    {formatRelativeDate(article.publishedAt)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* トレンド分析（簡易版） */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card className="animate-fade-in delay-300">
          <CardHeader>
            <CardTitle>販売会社別動向</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {['三菱UFJ銀行', '野村證券', 'ゆうちょ銀行', 'SBI証券'].map((company, i) => (
                <div key={company} className="flex items-center justify-between">
                  <span className="text-sm">{company}</span>
                  <div className="flex items-center gap-2">
                    <div className="text-sm font-medium tabular-nums">
                      {formatNumber(Math.floor(Math.random() * 50) + 10)}件
                    </div>
                    <Badge variant={i % 2 === 0 ? 'success' : 'secondary'} className="w-12 justify-center">
                      {i % 2 === 0 ? '+12%' : '→'}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="animate-fade-in delay-400">
          <CardHeader>
            <CardTitle>カテゴリ別記事数</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[
                { category: '投資信託', count: 45, change: 12 },
                { category: 'デジタル化', count: 28, change: 8 },
                { category: 'ESG', count: 22, change: -3 },
                { category: '手数料', count: 18, change: 5 },
              ].map(({ category, count, change }) => (
                <div key={category} className="flex items-center justify-between">
                  <span className="text-sm">{category}</span>
                  <div className="flex items-center gap-2">
                    <div className="text-sm font-medium tabular-nums">
                      {formatNumber(count)}件
                    </div>
                    <div className={`text-sm ${change > 0 ? 'text-[hsl(var(--increase))]' : 'text-[hsl(var(--decrease))]'}`}>
                      {formatPercent(change)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
