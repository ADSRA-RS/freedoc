import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.tsx'
import './index.css'
import { initializeMeilisearch, seedSampleData } from './lib/meilisearch'

// Meilisearchの初期化
initializeMeilisearch()
  .then(() => {
    console.log('Meilisearch ready')
    // 開発環境でサンプルデータを投入
    if (import.meta.env.DEV) {
      return seedSampleData()
    }
  })
  .catch(err => {
    console.error('Meilisearch initialization failed:', err)
  })

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
