import { MeiliSearch } from 'meilisearch'

const MEILI_HOST = import.meta.env.VITE_MEILI_HOST || 'http://localhost:7700'
const MEILI_SEARCH_KEY = import.meta.env.VITE_MEILI_SEARCH_KEY || 'masterKey123456'

export const meiliClient = new MeiliSearch({
  host: MEILI_HOST,
  apiKey: MEILI_SEARCH_KEY,
})

// Indexの型定義
export interface ArticleDocument {
  id: string
  title: string
  content: string
  summary: string
  source: 'ニッキン' | 'R&I' | 'その他'
  publishedAt: string
  category: string[]
  tags: string[]
  
  // 販売会社関連
  salesCompanyId?: string
  salesCompanyName?: string
  salesCompanyType?: '銀行' | '証券' | '保険' | 'その他'
  salesCompanyRegion?: string
  
  // 投資信託関連
  fundId?: string
  fundName?: string
  fundCategory?: string
  
  // メタデータ
  importance: 'high' | 'medium' | 'low'
  sentiment?: 'positive' | 'neutral' | 'negative'
  keywords: string[]
  relatedArticles?: string[]
  
  // 検索最適化用
  searchableText: string
  createdAt: string
  updatedAt: string
}

export const INDEX_NAME = 'sales_activities'

/**
 * Meilisearch Indexの初期化
 */
export async function initializeMeilisearch() {
  try {
    // Indexの作成または取得
    const index = meiliClient.index<ArticleDocument>(INDEX_NAME)
    
    // 検索可能な属性の設定
    await index.updateSearchableAttributes([
      'title',
      'content',
      'summary',
      'salesCompanyName',
      'fundName',
      'keywords',
      'tags',
      'searchableText',
    ])
    
    // フィルタリング可能な属性の設定
    await index.updateFilterableAttributes([
      'source',
      'category',
      'salesCompanyType',
      'salesCompanyRegion',
      'fundCategory',
      'importance',
      'sentiment',
      'publishedAt',
      'tags',
    ])
    
    // ソート可能な属性の設定
    await index.updateSortableAttributes([
      'publishedAt',
      'createdAt',
      'importance',
    ])
    
    // ランキングルールの設定
    await index.updateRankingRules([
      'words',
      'typo',
      'proximity',
      'attribute',
      'sort',
      'exactness',
      'publishedAt:desc',
    ])
    
    // ストップワード設定（日本語の助詞など）
    await index.updateStopWords([
      'の', 'に', 'は', 'を', 'た', 'が', 'で', 'て', 'と', 'し', 'れ', 'さ', 'ある', 'いる', 'も', 'する', 'から', 'な', 'こと', 'として', 'い', 'や', 'れる', 'など', 'なっ', 'ない', 'この', 'ため', 'その', 'あっ', 'よう', 'また', 'もの', 'という', 'あり', 'まで', 'られ', 'なる', 'へ', 'か', 'だ', 'これ', 'によって', 'により', 'おり', 'より', 'による', 'ず', 'なり', 'られる', 'において', 'ば', 'なかっ', 'なく', 'しかし', 'について', 'せ', 'だっ', 'その後', 'できる', 'それ', 'う', 'ので', 'なお', 'のみ', 'でき', 'き', 'つ', 'における', 'および', 'いう', 'さらに', 'でも', 'ら', 'たり', 'その他', 'に関する', 'たち', 'ます', 'ん', 'なら', 'に対して', '特に', 'せる', '及び', 'これら', 'とき', 'では', 'にて', 'ほか', 'ながら', 'うち', 'そして', 'とも', 'として', 'そこで', 'しまう', 'また', 'そう'
    ])
    
    console.log('Meilisearch initialized successfully')
    return index
  } catch (error) {
    console.error('Failed to initialize Meilisearch:', error)
    throw error
  }
}

/**
 * サンプルデータの投入（開発用）
 */
export async function seedSampleData() {
  const index = meiliClient.index<ArticleDocument>(INDEX_NAME)
  
  const sampleArticles: ArticleDocument[] = [
    {
      id: '1',
      title: '三菱UFJ銀行、投資信託販売で過去最高を記録',
      content: '三菱UFJ銀行は2024年第3四半期において投資信託販売額が前年同期比30%増加し、過去最高を記録した。特にNISA口座の開設が急増しており、若年層の投資意欲の高まりが背景にある。',
      summary: '三菱UFJ銀行の投信販売が前年比30%増で過去最高。NISA口座開設増加が要因。',
      source: 'ニッキン',
      publishedAt: '2024-10-15',
      category: ['投資信託', '銀行動向'],
      tags: ['NISA', '投資信託販売', '三菱UFJ銀行'],
      salesCompanyId: 'mufg-001',
      salesCompanyName: '三菱UFJ銀行',
      salesCompanyType: '銀行',
      salesCompanyRegion: '全国',
      importance: 'high',
      sentiment: 'positive',
      keywords: ['投資信託', 'NISA', '販売増加', '若年層'],
      searchableText: '三菱UFJ銀行 投資信託 販売 NISA 過去最高 前年比30%増',
      createdAt: '2024-10-15T09:00:00Z',
      updatedAt: '2024-10-15T09:00:00Z',
    },
    {
      id: '2',
      title: '野村證券、デジタル戦略を強化　オンライン相談を拡充',
      content: '野村證券は顧客接点のデジタル化を推進。ビデオ通話による投資相談サービスを全店舗で展開開始。従来の対面中心から、顧客の利便性を重視したハイブリッド型営業体制へ移行。',
      summary: '野村證券がデジタル戦略強化。全店舗でビデオ相談サービス開始。',
      source: 'ニッキン',
      publishedAt: '2024-10-12',
      category: ['証券動向', 'デジタル化'],
      tags: ['野村證券', 'DX', 'オンライン相談'],
      salesCompanyId: 'nomura-001',
      salesCompanyName: '野村證券',
      salesCompanyType: '証券',
      salesCompanyRegion: '全国',
      importance: 'high',
      sentiment: 'positive',
      keywords: ['デジタル化', 'オンライン', 'ビデオ相談', 'DX'],
      searchableText: '野村證券 デジタル戦略 オンライン相談 ビデオ通話 DX',
      createdAt: '2024-10-12T10:30:00Z',
      updatedAt: '2024-10-12T10:30:00Z',
    },
    {
      id: '3',
      title: 'ゆうちょ銀行、ESG投信の取扱いを大幅拡充',
      content: 'ゆうちょ銀行は環境・社会・ガバナンス（ESG）をテーマとした投資信託のラインナップを拡充。2025年1月から新たに15本のESG関連商品を追加し、合計30本体制に。',
      summary: 'ゆうちょ銀行がESG投信を拡充。2025年1月から15本追加し計30本に。',
      source: 'R&I',
      publishedAt: '2024-10-10',
      category: ['投資信託', 'ESG'],
      tags: ['ゆうちょ銀行', 'ESG', '投資信託'],
      salesCompanyId: 'yucho-001',
      salesCompanyName: 'ゆうちょ銀行',
      salesCompanyType: '銀行',
      salesCompanyRegion: '全国',
      fundCategory: 'ESG',
      importance: 'medium',
      sentiment: 'positive',
      keywords: ['ESG', '環境', '社会', 'ガバナンス', '投資信託'],
      searchableText: 'ゆうちょ銀行 ESG投資信託 環境 社会 ガバナンス',
      createdAt: '2024-10-10T14:00:00Z',
      updatedAt: '2024-10-10T14:00:00Z',
    },
    {
      id: '4',
      title: '地銀各行、手数料体系を見直し　透明性向上へ',
      content: '地方銀行70行以上が投資信託販売における手数料体系の見直しを発表。顧客への説明資料を刷新し、コスト構造の透明性を高める取り組みを開始。',
      summary: '地銀70行超が投信手数料体系見直し。透明性向上を図る。',
      source: 'ニッキン',
      publishedAt: '2024-10-08',
      category: ['銀行動向', '手数料'],
      tags: ['地方銀行', '手数料', '透明性'],
      salesCompanyType: '銀行',
      salesCompanyRegion: '地方',
      importance: 'high',
      sentiment: 'neutral',
      keywords: ['手数料', '透明性', '地方銀行', '見直し'],
      searchableText: '地方銀行 手数料 透明性 投資信託 コスト',
      createdAt: '2024-10-08T11:00:00Z',
      updatedAt: '2024-10-08T11:00:00Z',
    },
    {
      id: '5',
      title: 'SBI証券、米国株取引手数料を無料化',
      content: 'SBI証券は2024年11月より米国株式の取引手数料を完全無料化すると発表。ネット証券各社の競争が激化する中、顧客基盤の拡大を狙う。',
      summary: 'SBI証券が米国株取引手数料を11月から無料化。',
      source: 'ニッキン',
      publishedAt: '2024-10-05',
      category: ['証券動向', '手数料'],
      tags: ['SBI証券', '米国株', '手数料無料'],
      salesCompanyId: 'sbi-001',
      salesCompanyName: 'SBI証券',
      salesCompanyType: '証券',
      salesCompanyRegion: '全国',
      importance: 'high',
      sentiment: 'positive',
      keywords: ['手数料無料', '米国株', 'ネット証券', '競争'],
      searchableText: 'SBI証券 米国株 手数料無料 ネット証券',
      createdAt: '2024-10-05T09:30:00Z',
      updatedAt: '2024-10-05T09:30:00Z',
    },
  ]
  
  await index.addDocuments(sampleArticles)
  console.log('Sample data seeded successfully')
}
