import { create } from 'zustand'
import { ArticleDocument } from '@/lib/meilisearch'

interface FilterState {
  source: string[]
  salesCompanyType: string[]
  salesCompanyRegion: string[]
  importance: string[]
  dateRange: {
    start: string | null
    end: string | null
  }
  tags: string[]
}

interface SearchState {
  query: string
  filters: FilterState
  results: ArticleDocument[]
  totalHits: number
  isLoading: boolean
  error: string | null
  
  // Actions
  setQuery: (query: string) => void
  setFilters: (filters: Partial<FilterState>) => void
  resetFilters: () => void
  setResults: (results: ArticleDocument[], totalHits: number) => void
  setLoading: (isLoading: boolean) => void
  setError: (error: string | null) => void
}

const initialFilters: FilterState = {
  source: [],
  salesCompanyType: [],
  salesCompanyRegion: [],
  importance: [],
  dateRange: {
    start: null,
    end: null,
  },
  tags: [],
}

export const useSearchStore = create<SearchState>((set) => ({
  query: '',
  filters: initialFilters,
  results: [],
  totalHits: 0,
  isLoading: false,
  error: null,
  
  setQuery: (query) => set({ query }),
  
  setFilters: (newFilters) => set((state) => ({
    filters: { ...state.filters, ...newFilters }
  })),
  
  resetFilters: () => set({ filters: initialFilters }),
  
  setResults: (results, totalHits) => set({ results, totalHits }),
  
  setLoading: (isLoading) => set({ isLoading }),
  
  setError: (error) => set({ error }),
}))

// UI状態管理
interface UIState {
  sidebarOpen: boolean
  selectedArticle: ArticleDocument | null
  showOnboarding: boolean
  
  toggleSidebar: () => void
  setSelectedArticle: (article: ArticleDocument | null) => void
  setShowOnboarding: (show: boolean) => void
}

export const useUIStore = create<UIState>((set) => ({
  sidebarOpen: true,
  selectedArticle: null,
  showOnboarding: true,
  
  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
  setSelectedArticle: (article) => set({ selectedArticle: article }),
  setShowOnboarding: (show) => set({ showOnboarding: show }),
}))

// ダッシュボード KPI 管理
interface DashboardState {
  kpis: {
    totalArticles: number
    newArticlesThisWeek: number
    topSalesCompanies: Array<{ name: string; count: number }>
    topCategories: Array<{ category: string; count: number }>
  }
  setKPIs: (kpis: Partial<DashboardState['kpis']>) => void
}

export const useDashboardStore = create<DashboardState>((set) => ({
  kpis: {
    totalArticles: 0,
    newArticlesThisWeek: 0,
    topSalesCompanies: [],
    topCategories: [],
  },
  setKPIs: (kpis) => set((state) => ({
    kpis: { ...state.kpis, ...kpis }
  })),
}))
