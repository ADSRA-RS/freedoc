import { useState, useEffect } from 'react'
import { Search, X } from 'lucide-react'
import { meiliClient, INDEX_NAME, ArticleDocument } from '@/lib/meilisearch'
import { useSearchStore } from '@/stores/searchStore'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

export function SearchBar() {
  const { query, setQuery, setResults, setLoading, filters } = useSearchStore()
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [showSuggestions, setShowSuggestions] = useState(false)

  useEffect(() => {
    const delayDebounce = setTimeout(() => {
      if (query) {
        performSearch()
      } else {
        setResults([], 0)
      }
    }, 300)

    return () => clearTimeout(delayDebounce)
  }, [query, filters])

  const performSearch = async () => {
    try {
      setLoading(true)
      const index = meiliClient.index<ArticleDocument>(INDEX_NAME)
      
      // フィルタ条件の構築
      const filterConditions: string[] = []
      
      if (filters.source.length > 0) {
        filterConditions.push(`source IN [${filters.source.map(s => `"${s}"`).join(', ')}]`)
      }
      if (filters.salesCompanyType.length > 0) {
        filterConditions.push(`salesCompanyType IN [${filters.salesCompanyType.map(s => `"${s}"`).join(', ')}]`)
      }
      if (filters.importance.length > 0) {
        filterConditions.push(`importance IN [${filters.importance.map(s => `"${s}"`).join(', ')}]`)
      }
      
      const result = await index.search(query, {
        limit: 50,
        filter: filterConditions.length > 0 ? filterConditions.join(' AND ') : undefined,
        attributesToHighlight: ['title', 'summary'],
      })
      
      setResults(result.hits, result.estimatedTotalHits || 0)
    } catch (error) {
      console.error('Search error:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleClear = () => {
    setQuery('')
    setSuggestions([])
    setShowSuggestions(false)
  }

  return (
    <div className="relative w-full max-w-2xl">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <input
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value)
            setShowSuggestions(true)
          }}
          onFocus={() => setShowSuggestions(true)}
          placeholder="販売会社名、投資信託、キーワードで検索..."
          className={cn(
            "w-full pl-10 pr-10 py-3 rounded-lg border bg-background",
            "focus:outline-none focus:ring-2 focus:ring-ring",
            "text-sm transition-all"
          )}
        />
        {query && (
          <button
            onClick={handleClear}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* サジェスト（簡易実装） */}
      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute top-full mt-1 w-full bg-popover border rounded-lg shadow-lg z-50">
          <div className="p-2 space-y-1">
            {suggestions.map((suggestion, i) => (
              <button
                key={i}
                onClick={() => {
                  setQuery(suggestion)
                  setShowSuggestions(false)
                }}
                className="w-full text-left px-3 py-2 rounded hover:bg-accent text-sm"
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

export function ActiveFilters() {
  const { filters, setFilters } = useSearchStore()
  const activeFilters: Array<{ key: keyof typeof filters; value: string }> = []

  // アクティブなフィルタを収集
  Object.entries(filters).forEach(([key, value]) => {
    if (Array.isArray(value) && value.length > 0) {
      value.forEach(v => {
        activeFilters.push({ key: key as keyof typeof filters, value: v })
      })
    }
  })

  const removeFilter = (key: keyof typeof filters, value: string) => {
    const currentValues = filters[key] as string[]
    setFilters({
      [key]: currentValues.filter(v => v !== value)
    })
  }

  if (activeFilters.length === 0) return null

  return (
    <div className="flex flex-wrap gap-2 items-center">
      <span className="text-sm text-muted-foreground">絞り込み中:</span>
      {activeFilters.map((filter, i) => (
        <Badge
          key={`${filter.key}-${filter.value}-${i}`}
          variant="secondary"
          className="gap-1"
        >
          {filter.value}
          <button
            onClick={() => removeFilter(filter.key, filter.value)}
            className="ml-1 hover:text-destructive"
          >
            <X className="h-3 w-3" />
          </button>
        </Badge>
      ))}
    </div>
  )
}
