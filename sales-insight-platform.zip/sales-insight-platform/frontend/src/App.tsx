import { BrowserRouter, Routes, Route, Link, useLocation } from 'react-router-dom'
import { Menu, LayoutDashboard, Building2, Package, Search as SearchIcon, FileDown } from 'lucide-react'
import Dashboard from '@/pages/Dashboard'
import SalesCompanies from '@/pages/SalesCompanies'
import Products from '@/pages/Products'
import { Button } from '@/components/ui/button'
import { useUIStore } from '@/stores/searchStore'
import { cn } from '@/lib/utils'
import { Toaster } from 'sonner'

function Navigation() {
  const location = useLocation()
  const { sidebarOpen, toggleSidebar } = useUIStore()

  const navItems = [
    { path: '/', icon: LayoutDashboard, label: 'ダッシュボード' },
    { path: '/sales-companies', icon: Building2, label: '販売会社分析' },
    { path: '/products', icon: Package, label: '投信・商品分析' },
  ]

  return (
    <nav className={cn(
      "fixed left-0 top-0 h-full bg-card border-r transition-all duration-300 z-40",
      sidebarOpen ? "w-64" : "w-16"
    )}>
      <div className="flex flex-col h-full">
        {/* ヘッダー */}
        <div className="h-16 flex items-center justify-between px-4 border-b">
          {sidebarOpen && (
            <h1 className="font-bold text-lg bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
              Sales Insight
            </h1>
          )}
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleSidebar}
            className="flex-shrink-0"
          >
            <Menu className="h-5 w-5" />
          </Button>
        </div>

        {/* ナビゲーションアイテム */}
        <div className="flex-1 py-4 space-y-1 px-2">
          {navItems.map((item) => {
            const Icon = item.icon
            const isActive = location.pathname === item.path
            
            return (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors",
                  isActive 
                    ? "bg-primary text-primary-foreground" 
                    : "hover:bg-accent text-muted-foreground hover:text-foreground"
                )}
              >
                <Icon className="h-5 w-5 flex-shrink-0" />
                {sidebarOpen && (
                  <span className="text-sm font-medium">{item.label}</span>
                )}
              </Link>
            )
          })}
        </div>

        {/* フッター */}
        {sidebarOpen && (
          <div className="p-4 border-t text-xs text-muted-foreground">
            <p>© 2024 Sales Insight Platform</p>
            <p className="mt-1">野村アセットマネジメント</p>
          </div>
        )}
      </div>
    </nav>
  )
}

function Header() {
  return (
    <header className="h-16 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-30">
      <div className="h-full px-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <SearchIcon className="h-5 w-5 text-muted-foreground" />
          <span className="text-sm text-muted-foreground">
            Ctrl+K で高速検索
          </span>
        </div>
        
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="gap-2">
            <FileDown className="h-4 w-4" />
            エクスポート
          </Button>
        </div>
      </div>
    </header>
  )
}

function AppLayout({ children }: { children: React.ReactNode }) {
  const { sidebarOpen } = useUIStore()

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className={cn(
        "transition-all duration-300",
        sidebarOpen ? "ml-64" : "ml-16"
      )}>
        <Header />
        <main className="min-h-[calc(100vh-4rem)]">
          {children}
        </main>
      </div>
    </div>
  )
}

function App() {
  return (
    <BrowserRouter>
      <AppLayout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/sales-companies" element={<SalesCompanies />} />
          <Route path="/products" element={<Products />} />
        </Routes>
      </AppLayout>
      <Toaster position="bottom-right" />
    </BrowserRouter>
  )
}

export default App
