# Sales Insight Platform - プロジェクト概要書

## プロジェクト名
**Sales Insight Platform**  
野村アセットマネジメント 販売会社動向分析システム

---

## 1. プロジェクト概要

### 目的
資産運用会社の営業（RM）および営業企画担当者が、ニッキンやR&Iなどから入手した販売会社の動向記事を効率的に検索・分析し、実務で活用できる最高水準のWebアプリケーションを提供する。

### 対象ユーザー
- **メインユーザー**: 営業（RM）、営業企画
- **特性**: IT操作に不慣れな人が多数
- **利用目的**: 販売会社の戦略把握、投資信託の販売状況分析、営業提案の材料収集

### 解決する課題
1. 大量の記事情報から必要な情報を素早く見つけられない
2. Excel等での管理では検索性・分析性に限界がある
3. IT非熟練者にとって既存ツールが使いにくい

---

## 2. システム構成

### アーキテクチャ
```
┌─────────────────┐
│   フロントエンド   │  React + TypeScript + shadcn/ui
│   (Vite)        │  ポート: 5173
└────────┬────────┘
         │
         │ REST API
         │
┌────────▼────────┐
│   バックエンド    │  Express + TypeScript
│   (Node.js)    │  ポート: 3001
└────────┬────────┘
         │
         │ HTTP API
         │
┌────────▼────────┐
│  Meilisearch   │  検索エンジン
│                │  ポート: 7700
└─────────────────┘
```

### 技術スタック詳細

#### フロントエンド
| 技術 | バージョン | 用途 |
|------|-----------|------|
| React | 18.3.1 | UIフレームワーク |
| TypeScript | 5.3.3 | 型安全な開発 |
| Vite | 5.1.0 | ビルドツール |
| shadcn/ui | latest | UIコンポーネント |
| Tailwind CSS | 3.4.1 | スタイリング |
| Zustand | 4.5.0 | 状態管理 |
| React Router | 6.22.0 | ルーティング |
| React Hook Form | 7.50.0 | フォーム管理 |
| Zod | 3.22.4 | バリデーション |
| Recharts | 2.12.0 | チャート表示 |

#### バックエンド
| 技術 | バージョン | 用途 |
|------|-----------|------|
| Node.js | 20 | ランタイム |
| Express | 4.18.2 | Webフレームワーク |
| TypeScript | 5.3.3 | 型安全な開発 |

#### データベース・検索
| 技術 | バージョン | 用途 |
|------|-----------|------|
| Meilisearch | 1.6 | 高速全文検索エンジン |

#### インフラ
| 技術 | 用途 |
|------|------|
| Docker | コンテナ化 |
| Docker Compose | マルチコンテナ管理 |

---

## 3. 主要機能

### 3.1 ダッシュボード
- **目的**: 30秒で全体俯瞰
- **機能**:
  - KPIカード表示（総記事数、今週の新着、注目販売会社など）
  - 前年比・前月比の差分表示
  - トレンド可視化（色+矢印で直感的に）
  - 最新記事一覧
  - 販売会社別動向サマリー
  - カテゴリ別記事数

### 3.2 販売会社分析
- **目的**: 販売会社の動向を多角的に分析
- **機能**:
  - 高速検索（インクリメンタル検索、Typo耐性）
  - 多段階フィルタリング
    - 業態（銀行、証券、保険、その他）
    - 地域（全国、関東、関西など）
    - 情報源（ニッキン、R&I、その他）
    - 重要度（高、中、低）
  - 期間切替（1ヶ月、3ヶ月、年初来）
  - 検索結果一覧表示
  - ワンクリックCSVエクスポート

### 3.3 投信・商品分析
- **目的**: 投資信託と商品の動向分析
- **機能**:
  - カテゴリ別記事数の可視化
  - トレンド分析
  - チャート表示
  - 最新の商品関連記事一覧

---

## 4. UI/UX設計思想

### IT非熟練ユーザー向け三原則

#### 1. 考えさせない
- 選択肢を最小限に絞る
- デフォルト値を適切に設定
- 重要な情報を自動的に表示

#### 2. 迷わせない
- 遷移を浅く保つ（3クリック以内）
- 常に現在地を明示
- 明確な導線設計

#### 3. 失敗させない
- リセット機能の提供
- 操作の取り消し（Undo）
- 自動補完
- エラー防止ガード

### デザイン指針（金融向け）

#### カラーパレット
- **プライマリカラー**: 深い青（信頼性を表現）
- **セカンダリカラー**: ウォームグレー（中立性）
- **増加インジケーター**: 緑（色覚多様性対応）
- **減少インジケーター**: オレンジ（赤緑依存を避ける）

#### タイポグラフィ
- **メインフォント**: IBM Plex Sans（可読性重視）
- **日本語**: Noto Sans JP
- **数字**: タブラー数字（等幅）で比較しやすく

#### レイアウト
- カード型UIで情報を整理
- 適切な余白（ホワイトスペース）
- グリッドレイアウトで統一感

---

## 5. データモデル

### ArticleDocument（記事情報）

```typescript
interface ArticleDocument {
  // 基本情報
  id: string                    // 一意識別子
  title: string                 // タイトル
  content: string               // 本文
  summary: string               // 要約
  source: 'ニッキン' | 'R&I' | 'その他'  // 情報源
  publishedAt: string           // 公開日
  
  // カテゴリ・タグ
  category: string[]            // カテゴリ（複数可）
  tags: string[]                // タグ
  
  // 販売会社関連
  salesCompanyId?: string       // 販売会社ID
  salesCompanyName?: string     // 販売会社名
  salesCompanyType?: '銀行' | '証券' | '保険' | 'その他'
  salesCompanyRegion?: string   // 地域
  
  // 投資信託関連
  fundId?: string               // 投信ID
  fundName?: string             // 投信名
  fundCategory?: string         // 投信カテゴリ
  
  // メタデータ
  importance: 'high' | 'medium' | 'low'  // 重要度
  sentiment?: 'positive' | 'neutral' | 'negative'  // センチメント
  keywords: string[]            // キーワード
  relatedArticles?: string[]    // 関連記事ID
  
  // 検索最適化
  searchableText: string        // 検索用テキスト
  createdAt: string             // 作成日時
  updatedAt: string             // 更新日時
}
```

### Meilisearch Index設定

#### 検索可能属性（Searchable Attributes）
- title, content, summary
- salesCompanyName, fundName
- keywords, tags
- searchableText

#### フィルタリング可能属性（Filterable Attributes）
- source, category
- salesCompanyType, salesCompanyRegion
- fundCategory
- importance, sentiment
- publishedAt, tags

#### ソート可能属性（Sortable Attributes）
- publishedAt, createdAt
- importance

---

## 6. API仕様

### エンドポイント一覧

#### 検索
```
POST /api/search
Body: {
  query: string,
  filters?: string,
  limit?: number,
  offset?: number
}
Response: {
  hits: ArticleDocument[],
  totalHits: number,
  processingTimeMs: number
}
```

#### 記事取得
```
GET /api/articles/:id
Response: ArticleDocument
```

#### 統計情報
```
GET /api/stats
Response: {
  total: number,
  facets: {
    category: Record<string, number>,
    salesCompanyType: Record<string, number>,
    source: Record<string, number>
  }
}
```

#### 一括インポート
```
POST /api/articles/bulk
Body: {
  articles: ArticleDocument[]
}
Response: {
  taskUid: string,
  message: string
}
```

#### CSVエクスポート
```
POST /api/export/csv
Body: {
  query: string,
  filters?: string
}
Response: CSV file download
```

---

## 7. ディレクトリ構成

```
sales-insight-platform/
├── docker-compose.yml          # Docker統合設定
├── .env.example                # 環境変数サンプル
├── .gitignore                  # Git除外設定
├── README.md                   # プロジェクト説明
├── SETUP.md                    # セットアップガイド
├── QUICKSTART.md               # クイックスタート
├── start.bat                   # Windows起動スクリプト
├── start.sh                    # Mac/Linux起動スクリプト
│
├── frontend/                   # フロントエンド
│   ├── Dockerfile
│   ├── package.json
│   ├── tsconfig.json
│   ├── vite.config.ts
│   ├── tailwind.config.js
│   ├── postcss.config.js
│   ├── index.html
│   └── src/
│       ├── main.tsx           # エントリーポイント
│       ├── App.tsx            # メインアプリ
│       ├── index.css          # グローバルスタイル
│       ├── pages/             # ページコンポーネント
│       │   ├── Dashboard.tsx
│       │   ├── SalesCompanies.tsx
│       │   └── Products.tsx
│       ├── components/        # 共通コンポーネント
│       │   ├── ui/           # shadcn/ui コンポーネント
│       │   └── SearchBar.tsx
│       ├── stores/           # 状態管理
│       │   └── searchStore.ts
│       └── lib/              # ユーティリティ
│           ├── utils.ts
│           └── meilisearch.ts
│
└── backend/                   # バックエンド
    ├── Dockerfile
    ├── package.json
    ├── tsconfig.json
    └── src/
        └── index.ts          # Express サーバー
```

---

## 8. セットアップ手順

### 必要要件
- Docker Desktop（最新版）
- Git（オプション）

### クイックスタート
```bash
# 1. リポジトリ取得
git clone <repository-url>
cd sales-insight-platform

# 2. コンテナ起動
docker-compose up -d

# 3. ブラウザでアクセス
# http://localhost:5173
```

詳細は `SETUP.md` を参照。

---

## 9. 運用

### 日常的な使い方

#### 起動
```bash
docker-compose start
# または
./start.sh  # Mac/Linux
start.bat   # Windows
```

#### 停止
```bash
docker-compose stop
```

#### 完全削除
```bash
docker-compose down -v
```

### データ管理

#### インポート
```bash
curl -X POST http://localhost:3001/api/articles/bulk \
  -H "Content-Type: application/json" \
  -d @articles.json
```

#### エクスポート
- UI上の「エクスポート」ボタンからCSV出力

---

## 10. 今後の拡張予定

### フェーズ2（予定）
- [ ] PowerPointエクスポート機能
- [ ] 詳細な販売会社プロファイル
- [ ] レポート自動生成
- [ ] お気に入り/ブックマーク

### フェーズ3（検討中）
- [ ] チーム共有機能
- [ ] 通知・アラート
- [ ] ダッシュボードカスタマイズ
- [ ] API連携（外部システム）

---

## 11. サポート・お問い合わせ

技術的な問題やフィードバックは、プロジェクト担当者までご連絡ください。

### トラブルシューティング
- `SETUP.md` のトラブルシューティングセクションを参照
- `docker-compose logs` でログを確認
- コンテナの再起動: `docker-compose restart`

---

## 12. ライセンス・免責事項

本システムは野村アセットマネジメントの内部利用を目的としています。
第三者への再配布や商用利用は禁止されています。

---

## 付録: 用語集

| 用語 | 説明 |
|------|------|
| RM | リレーションシップマネージャー（営業担当者） |
| ニッキン | 日本金融通信社（業界専門紙） |
| R&I | 格付投資情報センター |
| ESG | 環境・社会・ガバナンス |
| NISA | 少額投資非課税制度 |
| Meilisearch | オープンソースの高速検索エンジン |
| shadcn/ui | Radix UIとTailwind CSSベースのコンポーネントライブラリ |
| Docker Compose | 複数のDockerコンテナを管理するツール |
