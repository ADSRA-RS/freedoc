# Sales Insight Platform

野村アセットマネジメント向け販売会社動向分析Webアプリケーション

## 概要

ニッキン、R&Iなどの記事情報を検索・分析し、営業（RM）や営業企画の実務をサポートする最高水準のWebアプリケーションです。

### 主な機能

- 📊 **ダッシュボード**: 30秒で全体俯瞰、KPI可視化
- 🏢 **販売会社分析**: 業態・地域別フィルタリング、詳細検索
- 📦 **投信・商品分析**: カテゴリ別トレンド分析
- 🔍 **高速検索**: Meilisearch による超高速・Typo耐性検索
- 📥 **エクスポート**: ワンクリックCSV出力

## 技術スタック

### フロントエンド
- **フレームワーク**: React 18 + TypeScript
- **UI**: shadcn/ui (Radix UI + Tailwind CSS)
- **状態管理**: Zustand
- **フォーム**: React Hook Form + Zod
- **チャート**: Recharts
- **ルーティング**: React Router v6

### バックエンド
- **ランタイム**: Node.js 20
- **フレームワーク**: Express
- **言語**: TypeScript

### データベース
- **検索エンジン**: Meilisearch v1.6
- **特徴**: 超高速フルテキスト検索、Typo耐性、Faceted Search

### インフラ
- **コンテナ**: Docker + Docker Compose
- **構成**: フロントエンド、バックエンド、Meilisearchの3コンテナ構成

## セットアップ

### 必要要件

- Docker Desktop (最新版推奨)
- Git

### クイックスタート

1. **リポジトリのクローン**
```bash
git clone <repository-url>
cd sales-insight-platform
```

2. **コンテナの起動**
```bash
docker-compose up -d
```

3. **アクセス**
- フロントエンド: http://localhost:5173
- バックエンドAPI: http://localhost:3001
- Meilisearch: http://localhost:7700

### 初回セットアップ

初回起動時、サンプルデータが自動的に投入されます。

## プロジェクト構成

```
sales-insight-platform/
├── docker-compose.yml          # Docker統合設定
├── frontend/                   # フロントエンドアプリケーション
│   ├── Dockerfile
│   ├── package.json
│   ├── vite.config.ts
│   ├── tailwind.config.js
│   ├── src/
│   │   ├── main.tsx           # エントリーポイント
│   │   ├── App.tsx            # メインアプリケーション
│   │   ├── pages/             # ページコンポーネント
│   │   │   ├── Dashboard.tsx # ダッシュボード
│   │   │   ├── SalesCompanies.tsx # 販売会社分析
│   │   │   └── Products.tsx  # 投信・商品分析
│   │   ├── components/        # 共通コンポーネント
│   │   │   ├── ui/           # shadcn/ui コンポーネント
│   │   │   └── SearchBar.tsx # 検索バー
│   │   ├── stores/           # Zustand ストア
│   │   │   └── searchStore.ts
│   │   └── lib/              # ユーティリティ
│   │       ├── utils.ts
│   │       └── meilisearch.ts
│   └── index.html
├── backend/                   # バックエンドAPI
│   ├── Dockerfile
│   ├── package.json
│   ├── tsconfig.json
│   └── src/
│       └── index.ts          # Express サーバー
└── README.md
```

## Meilisearch Index設計

### sales_activities Index

記事情報を格納する主要Index

#### 検索可能属性
- title (タイトル)
- content (本文)
- summary (要約)
- salesCompanyName (販売会社名)
- fundName (投信名)
- keywords (キーワード)
- tags (タグ)
- searchableText (検索最適化用テキスト)

#### フィルタリング可能属性
- source (情報源: ニッキン、R&I、その他)
- category (カテゴリ)
- salesCompanyType (業態: 銀行、証券、保険、その他)
- salesCompanyRegion (地域)
- fundCategory (投信カテゴリ)
- importance (重要度: high, medium, low)
- sentiment (センチメント: positive, neutral, negative)
- publishedAt (公開日)
- tags (タグ)

#### ソート可能属性
- publishedAt (公開日)
- createdAt (作成日)
- importance (重要度)

## UI/UX 設計思想

### IT非熟練ユーザー向け三原則

1. **考えさせない** - 選択肢を絞り、明確な導線を提供
2. **迷わせない** - 遷移を浅く、常に現在地を明示
3. **失敗させない** - Undo機能、自動補完、ガード処理

### デザイン指針（金融向け）

- ✅ 色数は最小限（ブランド色 + 強調色1色）
- ✅ 赤緑依存NG（色覚多様性対応：オレンジ/青使用）
- ✅ 数字は差分を主役に（前年比・前月比を強調）
- ✅ タブラー数字（等幅数字）で比較しやすく

### 主要機能

#### ダッシュボード
- KPIカード（前年差・前月差つき）
- トレンド可視化（色＋矢印で直感表示）
- アラート表示（異変検知）

#### 販売会社分析
- 左：フィルタ（業態・規模・地域）
- 中央：検索結果一覧
- 右：選択会社の詳細（今後実装予定）

#### 検索UX
- インクリメンタル検索（Enter不要）
- 候補補完（販売会社名・略称）
- Typo耐性（Meilisearch）

## 開発

### フロントエンド開発

```bash
cd frontend
npm install
npm run dev
```

### バックエンド開発

```bash
cd backend
npm install
npm run dev
```

### データ投入

バックエンドAPI経由で記事データを投入:

```bash
curl -X POST http://localhost:3001/api/articles/bulk \
  -H "Content-Type: application/json" \
  -d @data/articles.json
```

## API エンドポイント

### 検索
```
POST /api/search
Body: { query: string, filters?: string, limit?: number, offset?: number }
```

### 記事取得
```
GET /api/articles/:id
```

### 統計情報
```
GET /api/stats
```

### CSV エクスポート
```
POST /api/export/csv
Body: { query: string, filters?: string }
```

### 一括インポート
```
POST /api/articles/bulk
Body: { articles: ArticleDocument[] }
```

## 今後の拡張予定

- [ ] PowerPointエクスポート機能
- [ ] 詳細な販売会社プロファイル表示
- [ ] レポート自動生成
- [ ] お気に入り/ブックマーク機能
- [ ] チーム間での共有機能
- [ ] 通知・アラート設定
- [ ] ダッシュボードカスタマイズ

## トラブルシューティング

### コンテナが起動しない

```bash
# ログ確認
docker-compose logs

# 再ビルド
docker-compose down
docker-compose up --build
```

### Meilisearchに接続できない

Meilisearchコンテナが起動しているか確認:
```bash
docker-compose ps
curl http://localhost:7700/health
```

## ライセンス

Proprietary - 野村アセットマネジメント

## サポート

問題が発生した場合は、プロジェクト担当者までお問い合わせください。
