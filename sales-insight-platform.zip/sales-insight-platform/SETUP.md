# セットアップガイド

野村アセットマネジメント Sales Insight Platform のセットアップ手順

## 事前準備

### 必要なソフトウェア

1. **Docker Desktop**
   - Windows: https://www.docker.com/products/docker-desktop/
   - Mac: https://www.docker.com/products/docker-desktop/
   - 最新版を推奨

2. **Git** (オプション)
   - https://git-scm.com/downloads

## ステップ1: プロジェクトの取得

### 方法A: Gitでクローン（推奨）

```bash
git clone <repository-url>
cd sales-insight-platform
```

### 方法B: ZIPでダウンロード

1. プロジェクトをZIPでダウンロード
2. 解凍して適当なフォルダに配置
3. ターミナル/コマンドプロンプトでフォルダに移動

## ステップ2: Docker Desktopの起動

1. Docker Desktopを起動
2. Docker Desktopが完全に起動するまで待機（画面下部が緑色）

## ステップ3: アプリケーションの起動

### Windows (コマンドプロンプト or PowerShell)

```cmd
docker-compose up -d
```

### Mac/Linux (ターミナル)

```bash
docker-compose up -d
```

### 初回起動時の注意

- 初回は Docker イメージのダウンロードに時間がかかります（5-10分程度）
- インターネット接続が必要です
- 完了すると `✔ Container sales-insight-frontend Started` などが表示されます

## ステップ4: アクセス確認

### ブラウザで以下のURLにアクセス

1. **フロントエンド（メインアプリ）**
   - http://localhost:5173
   - ここがメインの作業画面です

2. **バックエンドAPI（確認用）**
   - http://localhost:3001/health
   - `{"status":"ok"}` と表示されればOK

3. **Meilisearch（確認用）**
   - http://localhost:7700
   - 検索エンジンの管理画面

## ステップ5: 動作確認

### フロントエンドで確認すべきこと

1. ダッシュボードが表示される
2. サンプルデータ（5件の記事）が表示される
3. 検索バーで「三菱UFJ」などを検索できる
4. サイドバーのメニューで画面遷移できる

### トラブルシューティング

#### ページが表示されない

```bash
# コンテナの状態確認
docker-compose ps

# すべてが "Up" になっていることを確認
# もし "Exit" や "Restarting" があれば...

# ログ確認
docker-compose logs frontend
docker-compose logs backend
docker-compose logs meilisearch

# 再起動
docker-compose restart
```

#### ポートが使用中のエラー

他のアプリケーションが同じポートを使用している可能性があります。

**docker-compose.yml を編集してポート番号を変更:**

```yaml
# 例: フロントエンドのポートを5173→5174に変更
frontend:
  ports:
    - "5174:5173"  # 左側を変更
```

#### データが表示されない

```bash
# コンテナを再起動
docker-compose restart

# それでもダメなら完全リセット
docker-compose down
docker-compose up -d
```

## ステップ6: 停止・再起動

### 停止

```bash
docker-compose stop
```

### 再起動

```bash
docker-compose start
```

### 完全削除（データも削除）

```bash
docker-compose down -v
```

## データのインポート

### 記事データのインポート方法

1. **JSONファイルを準備**

```json
[
  {
    "id": "unique-id-1",
    "title": "記事タイトル",
    "content": "記事本文...",
    "summary": "要約",
    "source": "ニッキン",
    "publishedAt": "2024-10-15",
    "category": ["投資信託"],
    "tags": ["NISA", "投資信託販売"],
    "salesCompanyName": "三菱UFJ銀行",
    "salesCompanyType": "銀行",
    "importance": "high",
    "keywords": ["投資信託", "NISA"],
    "searchableText": "三菱UFJ銀行 投資信託 NISA",
    "createdAt": "2024-10-15T09:00:00Z",
    "updatedAt": "2024-10-15T09:00:00Z"
  }
]
```

2. **APIでインポート**

```bash
curl -X POST http://localhost:3001/api/articles/bulk \
  -H "Content-Type: application/json" \
  -d @articles.json
```

## 日常的な使い方

### 起動

1. Docker Desktopを起動
2. ターミナルで `docker-compose start`
3. ブラウザで http://localhost:5173 を開く

### 停止

1. `docker-compose stop`
2. Docker Desktopを終了してもOK

## サポート

問題が解決しない場合は、以下の情報を添えてサポートまでご連絡ください：

- エラーメッセージ（スクリーンショットがあれば尚可）
- `docker-compose logs` の出力
- OS（Windows/Mac）とバージョン
- Docker Desktopのバージョン
