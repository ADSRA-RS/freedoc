# Docker構成ファイル完全版

このドキュメントには、プロジェクトで使用するすべてのDockerファイルの内容が含まれています。

---

## 1. docker-compose.yml (ルートディレクトリ)

**場所**: `/sales-insight-platform/docker-compose.yml`

```yaml
version: '3.8'

services:
  # Meilisearch - 検索エンジン
  meilisearch:
    image: getmeili/meilisearch:v1.6
    container_name: sales-insight-meilisearch
    ports:
      - "7700:7700"
    environment:
      - MEILI_ENV=development
      - MEILI_MASTER_KEY=masterKey123456
      - MEILI_NO_ANALYTICS=true
    volumes:
      - meilisearch_data:/meili_data
    networks:
      - sales-insight-network
    restart: unless-stopped

  # Backend API
  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    container_name: sales-insight-backend
    ports:
      - "3001:3001"
    environment:
      - NODE_ENV=development
      - MEILI_HOST=http://meilisearch:7700
      - MEILI_MASTER_KEY=masterKey123456
      - PORT=3001
    volumes:
      - ./backend:/app
      - /app/node_modules
    depends_on:
      - meilisearch
    networks:
      - sales-insight-network
    restart: unless-stopped

  # Frontend
  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    container_name: sales-insight-frontend
    ports:
      - "5173:5173"
    environment:
      - VITE_API_URL=http://localhost:3001
      - VITE_MEILI_HOST=http://localhost:7700
      - VITE_MEILI_SEARCH_KEY=masterKey123456
    volumes:
      - ./frontend:/app
      - /app/node_modules
    depends_on:
      - backend
    networks:
      - sales-insight-network
    restart: unless-stopped

networks:
  sales-insight-network:
    driver: bridge

volumes:
  meilisearch_data:
```

**説明**:
- 3つのサービス（meilisearch, backend, frontend）を定義
- 各サービスは独自のネットワークで接続
- Meilisearchのデータは永続化ボリュームに保存

---

## 2. frontend/Dockerfile

**場所**: `/sales-insight-platform/frontend/Dockerfile`

```dockerfile
FROM node:20-alpine

WORKDIR /app

COPY package*.json ./

RUN npm install

COPY . .

EXPOSE 5173

CMD ["npm", "run", "dev", "--", "--host", "0.0.0.0"]
```

**説明**:
- Node.js 20 Alpine版を使用（軽量）
- package.jsonを先にコピーしてnpm install（キャッシュ最適化）
- Vite開発サーバーを起動
- `--host 0.0.0.0` でDockerコンテナ外からアクセス可能に

---

## 3. backend/Dockerfile

**場所**: `/sales-insight-platform/backend/Dockerfile`

```dockerfile
FROM node:20-alpine

WORKDIR /app

COPY package*.json ./

RUN npm install

COPY . .

EXPOSE 3001

CMD ["npm", "run", "dev"]
```

**説明**:
- Node.js 20 Alpine版を使用
- package.jsonを先にコピーしてnpm install
- tsx watchで開発モード起動（ホットリロード対応）
- ポート3001でAPIサーバーを公開

---

## 起動コマンド

### すべてのコンテナを起動
```bash
docker-compose up -d
```

### ログを確認
```bash
docker-compose logs -f
```

### コンテナの状態確認
```bash
docker-compose ps
```

### コンテナを停止
```bash
docker-compose stop
```

### コンテナを削除（データは保持）
```bash
docker-compose down
```

### コンテナとデータを完全削除
```bash
docker-compose down -v
```

### 再ビルド
```bash
docker-compose up --build
```

---

## ポート一覧

| サービス | 内部ポート | 外部ポート | 用途 |
|---------|-----------|-----------|------|
| frontend | 5173 | 5173 | React開発サーバー |
| backend | 3001 | 3001 | Express APIサーバー |
| meilisearch | 7700 | 7700 | 検索エンジン |

---

## 環境変数

### フロントエンド
- `VITE_API_URL`: バックエンドAPIのURL
- `VITE_MEILI_HOST`: MeilisearchのURL
- `VITE_MEILI_SEARCH_KEY`: Meilisearchのマスターキー

### バックエンド
- `NODE_ENV`: 実行環境（development/production）
- `MEILI_HOST`: Meilisearchのホスト
- `MEILI_MASTER_KEY`: Meilisearchのマスターキー
- `PORT`: APIサーバーのポート番号

### Meilisearch
- `MEILI_ENV`: 実行環境
- `MEILI_MASTER_KEY`: マスターキー
- `MEILI_NO_ANALYTICS`: アナリティクス無効化

---

## ボリューム

### meilisearch_data
Meilisearchのデータを永続化するボリューム
- 場所: Docker管理領域
- データ: 記事情報、インデックス設定

**注意**: `docker-compose down -v` を実行するとこのデータも削除されます。

---

## ネットワーク

### sales-insight-network
すべてのコンテナが接続するブリッジネットワーク
- タイプ: bridge
- 用途: コンテナ間通信

---

## トラブルシューティング

### ポート競合エラー
他のアプリケーションが同じポートを使用している場合:

```yaml
# docker-compose.ymlのポートマッピングを変更
frontend:
  ports:
    - "5174:5173"  # 外部ポートを変更
```

### コンテナが起動しない
```bash
# 詳細ログを確認
docker-compose logs <service-name>

# 例
docker-compose logs frontend
docker-compose logs backend
docker-compose logs meilisearch
```

### node_modulesの問題
```bash
# コンテナを完全削除して再ビルド
docker-compose down
docker-compose up --build
```

### データがリセットされる
volumesが正しくマウントされているか確認:
```bash
docker volume ls
# meilisearch_dataがあることを確認
```

---

## 本番環境への展開

本番環境では以下の変更を推奨:

1. **環境変数の変更**
   - `NODE_ENV=production`
   - 強固なマスターキーを設定

2. **ビルドの最適化**
   ```dockerfile
   # フロントエンド
   RUN npm run build
   # Nginxなどで静的ファイルを配信
   ```

3. **セキュリティ強化**
   - ポートの制限
   - HTTPSの使用
   - ファイアウォール設定

---

## まとめ

✅ すべてのDockerファイルが正しく配置されています
✅ docker-compose.ymlで3つのサービスを統合管理
✅ ホットリロード対応で開発効率が高い
✅ データは永続化ボリュームに保存

起動は `docker-compose up -d` だけ！
