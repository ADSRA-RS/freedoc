# プロジェクト構造

## 完全なディレクトリツリー

```
sales-insight-platform/
│
├── docker-compose.yml          ✅ Docker統合設定ファイル
├── .env.example                ✅ 環境変数サンプル
├── .gitignore                  ✅ Git除外設定
│
├── README.md                   📖 プロジェクト全体の説明
├── PROJECT_OVERVIEW.md         📖 詳細な概要書
├── SETUP.md                    📖 セットアップガイド
├── QUICKSTART.md               📖 クイックスタート
│
├── start.bat                   🚀 Windows用起動スクリプト
├── start.sh                    🚀 Mac/Linux用起動スクリプト
│
├── frontend/                   💻 フロントエンドアプリケーション
│   ├── Dockerfile              ✅ フロントエンドDockerfile
│   ├── package.json            📦 npm依存関係
│   ├── tsconfig.json           ⚙️  TypeScript設定
│   ├── tsconfig.node.json      ⚙️  Node用TypeScript設定
│   ├── vite.config.ts          ⚙️  Vite設定
│   ├── tailwind.config.js      🎨 Tailwind CSS設定
│   ├── postcss.config.js       🎨 PostCSS設定
│   ├── index.html              📄 HTMLエントリーポイント
│   │
│   └── src/
│       ├── main.tsx            🚪 アプリケーションエントリー
│       ├── App.tsx             🏠 メインアプリコンポーネント
│       ├── index.css           🎨 グローバルスタイル
│       │
│       ├── pages/              📱 ページコンポーネント
│       │   ├── Dashboard.tsx       - ダッシュボード
│       │   ├── SalesCompanies.tsx  - 販売会社分析
│       │   └── Products.tsx        - 投信・商品分析
│       │
│       ├── components/         🧩 共通コンポーネント
│       │   ├── SearchBar.tsx       - 検索バー
│       │   └── ui/                 - shadcn/uiコンポーネント
│       │       ├── button.tsx
│       │       ├── card.tsx
│       │       ├── badge.tsx
│       │       └── tabs.tsx
│       │
│       ├── stores/             🗄️  状態管理（Zustand）
│       │   └── searchStore.ts      - 検索・UI状態
│       │
│       └── lib/                🛠️  ユーティリティ
│           ├── utils.ts            - 汎用関数
│           └── meilisearch.ts      - Meilisearch設定
│
└── backend/                    🔧 バックエンドAPI
    ├── Dockerfile              ✅ バックエンドDockerfile
    ├── package.json            📦 npm依存関係
    ├── tsconfig.json           ⚙️  TypeScript設定
    │
    └── src/
        └── index.ts            🚪 Expressサーバー
```

## Docker構成の詳細

### 1. docker-compose.yml
3つのサービスを統合管理：

```yaml
services:
  meilisearch:   # 検索エンジン (ポート 7700)
  backend:       # ExpressAPI (ポート 3001)
  frontend:      # React App (ポート 5173)
```

### 2. frontend/Dockerfile
Node.js 20ベースのフロントエンドコンテナ
- Vite開発サーバー起動
- ホットリロード対応

### 3. backend/Dockerfile
Node.js 20ベースのバックエンドコンテナ
- Express APIサーバー
- TypeScript実行環境

## ファイルの確認

すべてのDockerファイルが正しく配置されています：

✅ `/docker-compose.yml`
✅ `/frontend/Dockerfile`
✅ `/backend/Dockerfile`

## 起動方法

### 方法1: 起動スクリプト使用
```bash
# Windows
start.bat

# Mac/Linux  
./start.sh
```

### 方法2: 直接コマンド
```bash
docker-compose up -d
```

## アクセスURL

起動後、以下のURLにアクセス：

- **フロントエンド**: http://localhost:5173
- **バックエンドAPI**: http://localhost:3001
- **Meilisearch**: http://localhost:7700

## トラブルシューティング

### Dockerファイルが見つからないエラー
プロジェクトのルートディレクトリで実行していることを確認してください。

```bash
# 現在のディレクトリ確認
pwd

# 正しい場所にいるか確認
ls -la | grep docker-compose.yml
```

### コンテナが起動しない
```bash
# ログ確認
docker-compose logs

# 再ビルド
docker-compose up --build
```
