#!/bin/bash

echo "========================================"
echo "Sales Insight Platform"
echo "野村アセットマネジメント"
echo "========================================"
echo ""

echo "[1/3] Docker起動確認..."
if ! docker info > /dev/null 2>&1; then
    echo "❌ Dockerが起動していません"
    echo ""
    echo "手順:"
    echo "1. Docker Desktopを起動してください"
    echo "2. 完全に起動するまで待機してください"
    echo "3. このスクリプトを再実行してください"
    exit 1
fi
echo "✅ Docker 起動中"

echo ""
echo "[2/3] コンテナの起動..."
docker-compose up -d
if [ $? -ne 0 ]; then
    echo "❌ コンテナの起動に失敗しました"
    exit 1
fi

echo ""
echo "[3/3] 起動完了待機..."
sleep 5

echo ""
echo "========================================"
echo "✅ 起動完了!"
echo "========================================"
echo ""
echo "アクセスURL:"
echo "  フロントエンド: http://localhost:5173"
echo "  バックエンドAPI: http://localhost:3001"
echo "  Meilisearch: http://localhost:7700"
echo ""
echo "停止するには: docker-compose stop"
echo "========================================"
echo ""

# Macの場合ブラウザを開く
if [[ "$OSTYPE" == "darwin"* ]]; then
    echo "ブラウザを開きます..."
    sleep 2
    open http://localhost:5173
fi
