import express from 'express'
import cors from 'cors'
import { MeiliSearch } from 'meilisearch'
import dotenv from 'dotenv'

dotenv.config()

const app = express()
const PORT = process.env.PORT || 3001

// Meilisearch client
const meiliClient = new MeiliSearch({
  host: process.env.MEILI_HOST || 'http://meilisearch:7700',
  apiKey: process.env.MEILI_MASTER_KEY || 'masterKey123456',
})

// Middleware
app.use(cors())
app.use(express.json())

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() })
})

// Search endpoint
app.post('/api/search', async (req, res) => {
  try {
    const { query, filters, limit = 50, offset = 0 } = req.body
    
    const index = meiliClient.index('sales_activities')
    const result = await index.search(query || '', {
      filter: filters,
      limit,
      offset,
      attributesToHighlight: ['title', 'summary'],
    })
    
    res.json({
      hits: result.hits,
      totalHits: result.estimatedTotalHits,
      processingTimeMs: result.processingTimeMs,
    })
  } catch (error) {
    console.error('Search error:', error)
    res.status(500).json({ error: 'Search failed' })
  }
})

// Get article by ID
app.get('/api/articles/:id', async (req, res) => {
  try {
    const { id } = req.params
    const index = meiliClient.index('sales_activities')
    const document = await index.getDocument(id)
    
    res.json(document)
  } catch (error) {
    console.error('Get article error:', error)
    res.status(404).json({ error: 'Article not found' })
  }
})

// Get statistics
app.get('/api/stats', async (req, res) => {
  try {
    const index = meiliClient.index('sales_activities')
    const stats = await index.getStats()
    
    // カテゴリ別集計
    const categoryResult = await index.search('', {
      facets: ['category', 'salesCompanyType', 'source'],
      limit: 0,
    })
    
    res.json({
      total: stats.numberOfDocuments,
      facets: categoryResult.facetDistribution,
    })
  } catch (error) {
    console.error('Stats error:', error)
    res.status(500).json({ error: 'Failed to get stats' })
  }
})

// Bulk upload (for data import)
app.post('/api/articles/bulk', async (req, res) => {
  try {
    const { articles } = req.body
    
    if (!Array.isArray(articles)) {
      return res.status(400).json({ error: 'Articles must be an array' })
    }
    
    const index = meiliClient.index('sales_activities')
    const task = await index.addDocuments(articles)
    
    res.json({ taskUid: task.taskUid, message: 'Import started' })
  } catch (error) {
    console.error('Bulk upload error:', error)
    res.status(500).json({ error: 'Bulk upload failed' })
  }
})

// Export to CSV
app.post('/api/export/csv', async (req, res) => {
  try {
    const { query, filters } = req.body
    const index = meiliClient.index('sales_activities')
    
    const result = await index.search(query || '', {
      filter: filters,
      limit: 1000, // 最大1000件まで
    })
    
    // CSV生成（簡易版）
    const headers = ['ID', 'タイトル', '情報源', '販売会社', '公開日']
    const rows = result.hits.map(hit => [
      hit.id,
      `"${hit.title.replace(/"/g, '""')}"`,
      hit.source,
      hit.salesCompanyName || '',
      hit.publishedAt,
    ])
    
    const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n')
    
    res.setHeader('Content-Type', 'text/csv; charset=utf-8')
    res.setHeader('Content-Disposition', 'attachment; filename=export.csv')
    res.send('\uFEFF' + csv) // BOM for Excel
  } catch (error) {
    console.error('Export error:', error)
    res.status(500).json({ error: 'Export failed' })
  }
})

// Error handling
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('Error:', err)
  res.status(500).json({ error: 'Internal server error' })
})

app.listen(PORT, () => {
  console.log(`🚀 Backend server running on port ${PORT}`)
  console.log(`📊 Meilisearch host: ${process.env.MEILI_HOST || 'http://meilisearch:7700'}`)
})
