#!/bin/bash

echo "========================================="
echo "Sales Insight Platform"
echo "ファイル構成チェック"
echo "========================================="
echo ""

# 色の定義
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# チェック関数
check_file() {
    if [ -f "$1" ]; then
        echo -e "${GREEN}✓${NC} $1"
        return 0
    else
        echo -e "${RED}✗${NC} $1 (見つかりません)"
        return 1
    fi
}

check_dir() {
    if [ -d "$1" ]; then
        echo -e "${GREEN}✓${NC} $1/"
        return 0
    else
        echo -e "${RED}✗${NC} $1/ (見つかりません)"
        return 1
    fi
}

# カウンター
total=0
passed=0

echo "【Docker関連ファイル】"
check_file "docker-compose.yml"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
check_file "frontend/Dockerfile"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
check_file "backend/Dockerfile"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
echo ""

echo "【ドキュメント】"
check_file "README.md"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
check_file "SETUP.md"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
check_file "QUICKSTART.md"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
check_file "PROJECT_OVERVIEW.md"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
check_file "DOCKER_GUIDE.md"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
check_file "FILE_STRUCTURE.md"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
echo ""

echo "【起動スクリプト】"
check_file "start.sh"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
check_file "start.bat"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
echo ""

echo "【設定ファイル】"
check_file ".gitignore"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
check_file ".env.example"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
echo ""

echo "【フロントエンド】"
check_dir "frontend"
check_file "frontend/package.json"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
check_file "frontend/tsconfig.json"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
check_file "frontend/vite.config.ts"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
check_file "frontend/tailwind.config.js"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
check_file "frontend/index.html"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
check_dir "frontend/src"
check_file "frontend/src/main.tsx"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
check_file "frontend/src/App.tsx"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
echo ""

echo "【バックエンド】"
check_dir "backend"
check_file "backend/package.json"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
check_file "backend/tsconfig.json"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
check_dir "backend/src"
check_file "backend/src/index.ts"; total=$((total+1)); [ $? -eq 0 ] && passed=$((passed+1))
echo ""

echo "========================================="
echo "結果: $passed/$total ファイルが存在"
echo "========================================="

if [ $passed -eq $total ]; then
    echo -e "${GREEN}✓ すべてのファイルが揃っています！${NC}"
    echo ""
    echo "起動するには:"
    echo "  docker-compose up -d"
    exit 0
else
    echo -e "${RED}✗ 一部のファイルが見つかりません${NC}"
    exit 1
fi
